import React from 'react';
import Header from "./Header/header";

const App=()=>{
  return(
    <>
    <Header/>
      
  </>
  )
}
export default App;